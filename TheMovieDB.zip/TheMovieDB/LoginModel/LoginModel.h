//
//  LoginModel.h
//  LoginModel
//
//  Created by jianli on 4/6/22.
//

#import <Foundation/Foundation.h>

//! Project version number for LoginModel.
FOUNDATION_EXPORT double LoginModelVersionNumber;

//! Project version string for LoginModel.
FOUNDATION_EXPORT const unsigned char LoginModelVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LoginModel/PublicHeader.h>


